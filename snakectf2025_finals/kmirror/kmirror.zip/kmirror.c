#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/mm.h>

#define KMIRROR_IOCTL_SET_TARGET_ADDR _IOW('m', 0, void *)
#define KMIRROR_IOCTL_GET_TARGET_ADDR _IOR('m', 1, void *)

static long kmirror_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    int ret = 0;

    switch (cmd)
    {
    case KMIRROR_IOCTL_SET_TARGET_ADDR:
        filp->private_data = (void *)arg;
        break;

    case KMIRROR_IOCTL_GET_TARGET_ADDR:
        ret = copy_to_user((void __user *)arg, &filp->private_data, sizeof(void *));
        break;

    default:

        ret = -EINVAL;
    }

    return ret;
}

static void kmirror_vma_close(struct vm_area_struct *vma)
{
    if (vma->vm_private_data)
    {
        put_page((struct page *)vma->vm_private_data);
    }
}

static int kmirror_vma_may_split(struct vm_area_struct *vma, unsigned long addr)
{
    return -EINVAL;
}

static int kmirror_vma_mremap(struct vm_area_struct *vma)
{
    return -EINVAL;
}

static int kmirror_vma_mprotect(struct vm_area_struct *vma, unsigned long start, unsigned long end, unsigned long newflags)
{
    return -EINVAL;
}

static struct vm_operations_struct kmirror_vm_ops = {
    .close = kmirror_vma_close,
    .may_split = kmirror_vma_may_split,
    .mremap = kmirror_vma_mremap,
    .mprotect = kmirror_vma_mprotect,
};

static int kmirror_mmap(struct file *filp, struct vm_area_struct *vma)
{
    int ret = 0;

    if (vma_pages(vma) != 1 || vma->vm_pgoff != 0)
    {
        ret = -EINVAL;
        goto out;
    }

    struct vm_area_struct *target_vma = vma_lookup(vma->vm_mm, (unsigned long)filp->private_data);
    if (!target_vma)
    {
        ret = -ENOENT;
        goto out;
    }

    if (pgprot_val(target_vma->vm_page_prot) != pgprot_val(vma->vm_page_prot))
    {
        ret = -EPERM;
        goto out;
    }

    struct page *target_page;
    if (get_user_pages((unsigned long)filp->private_data, vma_pages(vma), FOLL_GET, &target_page) != 1)
    {
        ret = -EFAULT;
        goto out;
    }

    vm_flags_set(vma, VM_IO | VM_PFNMAP | VM_DONTEXPAND | VM_DONTDUMP | VM_DONTCOPY);
    vma->vm_ops = &kmirror_vm_ops;
    vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
    vma->vm_private_data = target_page;

    if (vm_iomap_memory(vma, page_to_phys(target_page), PAGE_SIZE))
    {
        put_page(target_page);
        ret = -EFAULT;
    }

out:
    return ret;
}

static struct file_operations kmirror_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = kmirror_ioctl,
    .mmap = kmirror_mmap,
};

static struct miscdevice kmirror_dev = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = "kmirror",
    .fops = &kmirror_fops};

static int __init mod_init(void)
{
    if (misc_register(&kmirror_dev))
    {
        pr_err("kmirror: failed to register misc device\n");
        return -1;
    }

    return 0;
}

static void __exit mod_exit(void)
{
    misc_deregister(&kmirror_dev);
}

module_init(mod_init);
module_exit(mod_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("c0mm4nd_");
MODULE_DESCRIPTION("snakeCTF 2025 Finals - challenge");
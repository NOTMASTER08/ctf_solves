#!/bin/sh

FLAG_TMP=$(mktemp --tmpdir flag.XXXXXXX)
echo ${FLAG:-snakeCTF\{placeholder\}} > $FLAG_TMP

if [ $# -le 0 ]; then
    qemu-system-x86_64 \
        -kernel ./bzImage \
        -cpu qemu64,+smep,+smap,+rdrand \
        -smp 2 \
        -m 1G \
        -drive file=$FLAG_TMP,format=raw,index=0 \
        -initrd ./initramfs.cpio.gz \
        -append "console=ttyS0 quiet loglevel=3 oops=panic panic_on_warn=1 panic=-1 pti=on" \
        -monitor /dev/null \
        -nographic \
        -no-reboot
else
    EXPLOIT=$1
    if [ ! -f "$EXPLOIT" ]; then
        touch $EXPLOIT
    fi

    qemu-system-x86_64 \
        -kernel ./bzImage \
        -cpu qemu64,+smep,+smap,+rdrand \
        -smp 2 \
        -m 1G \
        -drive file=$FLAG_TMP,format=raw,index=0 \
        -drive file=$EXPLOIT,format=raw,index=1 \
        -initrd ./initramfs.cpio.gz \
        -append "console=ttyS0 quiet loglevel=3 oops=panic panic_on_warn=1 panic=-1 pti=on" \
        -monitor /dev/null \
        -nographic \
        -no-reboot
fi